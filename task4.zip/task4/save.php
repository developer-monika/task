<?php

$connection = mysqli_connect('localhost', 'root', '', 'task4_db');
$query = "select * from user where user =  '$_POST[user]' AND password = '$_POST[pass]'";
echo '<br>';
$res =  mysqli_query($connection,$query);
if ($res AND mysqli_num_rows($res) != 0) {
	while($row = mysqli_fetch_assoc($res)) {
		echo '<pre>';print_r($row);
		// echo $row['user'] . '<br>' ;
		// echo $row['password'] . '<br>' ;
	}
}
else if (!$res) {
	echo 'Error in query' . mysqli_error();
}
else if (mysqli_num_rows($res) == 0)  {
	echo 'No match.';
}




 ?>