<form method=post action="save.php">
User: <input type=text name="user">
<br />
Password: <input type=text name="pass">
<input type="submit" name="sbumit1">
</form>


<!--   'or 1=1 or'    -->