SQL is the acronym for Structured Query Language. It is used to retrieve and manipulate data in the database. SQL Injection is an attack that poisons dynamic SQL statements to comment out certain parts of the statement or appending a condition that will always be true.


<br/>
<br/>
SQL Injection

SQL injection is a code injection technique that might destroy your database.

SQL injection is one of the most common web hacking techniques.

SQL injection is the placement of malicious code in SQL statements, via web page input.



Example
txtUserId = getRequestString("UserId");
txtSQL = "SELECT * FROM Users WHERE UserId = " + txtUserId;



SQL Injection Based on 1=1 is Always True

UserId: 105 OR 1=1

Then, the SQL statement will look like this:

SELECT UserId, Name, Password FROM Users WHERE UserId = 105 or 1=1;

The SQL above is valid and will return ALL rows from the "Users" table, since OR 1=1 is always TRUE.

====================================================================================================

SQL Injection Based on ""="" is Always True

Username
<input type="text">

Password
<input type="password">

SELECT * FROM Users WHERE Name ="John Doe" AND Pass ="myPass"


A hacker might get access to user names and passwords in a database by simply inserting " OR ""=" into the user name or password text box:

User Name:
" or ""="

Password
" or ""="

then
SELECT * FROM Users WHERE Name ="" or ""="" AND Pass ="" or ""=""

The SQL above is valid and will return all rows from the "Users" table, since OR ""="" is always TRUE.

=========================================================================================================

prevention technique:

 you can use the mysql\_real\_escape\_string() to escape characters that might change the nature of the SQL command.

$con=mysqli_connect("localhost","user","password","db");
$username = mysqli_real_escape_string($con, $_POST['username']); 
$password = mysqli_real_escape_string($con, $_POST['password']); 
$sql_command = "select * from users where username = '" . $username; 
$sql_command .= "' AND password = '" . $password . "'"; 


