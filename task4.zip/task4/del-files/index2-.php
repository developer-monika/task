<?php
$connection=mysql_connect("localhost","root","");
mysql_select_db("task4_db",$connection);
$a=$_POST['email'];
$b=$_POST['password'];
$que="insert into task4_tbl (email,password) values ('$a','$b')";
$data=mysql_query($que);
?>
<!DOCTYPE html>
<html>
<head>
	<title>SQL Injection</title>
	<style type="text/css">
		.container{
			margin: 0 auto;
			width: 700px;
		}
	</style>
</head>
<body class="container">
<br/><br/><br/>
<form action="index.php" method="post">

<input type="email" name="email" required="required"/>

<input type="password" name="password"/>

<input type="checkbox" name="remember_me" value="Remember me"/>

<input type="submit" value="Submit"/>

</form>
<br/>
</body>
</html>