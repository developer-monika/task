<?php
// Test SQL injection
// This feature has been DEPRECATED as of PHP 5.3.0
//var_dump(get_magic_quotes_gpc());
$con=mysql_connect('localhost', 'root', '') or die('DB Conn error');
mysql_select_db('task4_db',$con);
echo $query = "select * from task4_tbl where email =  '$_POST[email]' AND password = '$_POST[password]'";
echo '<br>';
$res = mysql_query($query);
if ($res AND mysql_num_rows($res) != 0) {
	while($row = mysql_fetch_assoc($res)) {
		print_r($row);
		echo $row['Ename'] . '<br>' ;
	}
}
else if (!$res) {
	echo 'Error in query' . mysql_error();
}
else if (mysql_num_rows($res) == 0)  {
	echo 'No match.';
}
?>
<form method="post" action="">
User: <input type=text name="email">
<br />
Password: <input type=text name="password">
<input type="submit" name="sbumit1">
</form>