<!DOCTYPE html>
<html>
<head>
	<title>CRON</title>
</head>
<body>
<!-- url-->
<!--http://stackoverflow.com/questions/18737407/how-to-create-cron-job-using-php-->
<!--http://stackoverflow.com/questions/16144350/executing-a-php-script-with-a-cron-job-->
<!-- https://code.tutsplus.com/tutorials/scheduling-tasks-with-cron-jobs--net-8800-->
<h5>Server admins have been using cron jobs for a long time. But since the target audience of this article is web developers, let's look at a few use cases of cron jobs that are relevant in this area:<br/>

If you have a membership site, where accounts have expiration dates, you can schedule cron jobs to regularly deactivate or delete accounts that are past their expiration dates.<br/>
You can send out daily newsletter e-mails.<br/>
If you have summary tables (or materialized views) in your database, they can be regularly updated with a cron job. For example you may store every web page hit in a table, but another summary table may contain daily traffic summaries.<br/>
You can expire and erase cached data files in a certain interval.<br/>
You can auto-check your website content for broken links and have a report e-mailed to yourself regularly.<br/>
You can schedule long-running tasks to run from a command line script, rather than running it from a web script. Like encoding videos, or sending out mass e-mails.<br/>
You can even perform something as simple as fetching your most recent Tweets, to be cached in a text file.</h5>
</body>
</html>