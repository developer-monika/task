<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Task1</title>
     <!-- Bootstrap -->
    <!--<link href="css/bootstrap.min.css" rel="stylesheet">-->
	<link href="../css/bootstrap.css" rel="stylesheet">
	<link href="../css/style.css" rel="stylesheet">
  .error{
  color:red;
  font-weight:bold;
  }
  </head>
  <body>


<?php 
include  '../db.php';
include '../user_header.php';
?>
    

    <div class="container">
      <br/><br/><br/><br/><br/><br/><br/><br/>
    <!-- Main form -->
   <div class="container">
            <form class="form-horizontal" role="form" action="auth.php" method="post">
                <h2>Login Form</h2>
               
                <div class="form-group">
                    <label for="" class="col-sm-3 control-label">Email</label>
                    <div class="col-sm-9">
                        <input type="text" id="" name="v_username" placeholder="Email" class="form-control" 
                        value="">
                    </div>
                </div>
                <div class="form-group">
                    <label for="password" class="col-sm-3 control-label">Password</label>
                    <div class="col-sm-9">
                        <input type="password" id="password" name="v_password" placeholder="Password" class="form-control">
                    </div>
                </div>
               
                <div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                        <button type="submit" name="submit" class="btn btn-primary btn-block">Login</button>
                    </div>
                </div>
               
            </form> <!-- /form -->
            <?php
            if(isset($_SESSION ['msg']))
            {
              echo $_SESSION['msg'];
              unset($_SESSION['msg']);
            }
            ?>
        </div> <!-- ./container -->

    </div> <!-- /container -->
       <br/><br/><br/><br/><hr>
<?php include '../footer.php'; ?>
   

    
  </body>
</html>