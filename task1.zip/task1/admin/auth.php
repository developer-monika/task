<?php
include("../db.php");
// print_r($_POST);
// die;
$u=$_POST['v_username'];
$p=$_POST['v_password'];
$p=md5($p);
$que="SELECT * FROM admin_tbl WHERE username='$u'";
$obj=mysql_query($que);
if(mysql_num_rows($obj)==1)
{
	$data=mysql_fetch_assoc($obj);
	if($data['password']==$p)
	{
		$_SESSION['is_admin_logged_in']=true;
		$_SESSION['id']=$data['id'];
		header("location:dashboard.php");
	}
	else{
		$_SESSION['msg']="This password is incorrect !";
		header("location:index.php");		
	}
}
else
{
    $_SESSION['msg']="This username and password is incorrect !";
	header("location:index.php");
}
?>