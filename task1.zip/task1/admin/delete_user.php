<?php
//include("../db.php");
//if(! isset($_SESSION['is_admin_logged_in']))
//{
  //header("location:../index.php");
//}
//$id=$_GET['id'];
//$que="DELETE FROM info_tbl WHERE id=$id";


// if ($con->mysql_query($que) === TRUE) {
//     echo "Record deleted successfully";
// } else {
//     echo "Error deleting record: " . $con->error;
// }
// $con->close();
//header('location:view_all_user.php');

include("../db.php");
if(! isset($_SESSION['is_admin_logged_in']))
{
  header("location:../index.php");
}

// sql to delete a record
$id=$_GET['id'];
$sql = "DELETE FROM info_tbl WHERE id=$id";
$obj= mysql_query($sql);
header('location:view_all_user.php');
// if ($con->query($sql) === TRUE) {
//     echo "Record deleted successfully";
// } else {
//     echo "Error deleting record: " . $con->error;
// }

//$con->close();
?>