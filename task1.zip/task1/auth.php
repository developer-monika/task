<?php
include("db.php");

$u = $_POST['username'];
$p = $_POST['password'];
$p = md5($p);

$que ="SELECT * FROM info_tbl WHERE username='$u'";
$obj = mysql_query($que);
 //echo (mysql_num_rows($onj));
if (mysql_num_rows($obj)==1) 
{
	$data = mysql_fetch_assoc($obj);
	// print_r($data);
	// die;

	if ($data['password']==$p) 
	{
	 $_SESSION['id']=$data['id'];
	 $_SESSION['name']=$data['username'];
	 $_SESSION['contact'].$data['contact'];
	 $_SESSION['is_user_logged_in']=true;
	 header("location:dashboard.php");	
	}
	else{
		$_SESSION ['username']=$u;
		$_SESSION ['msg']="This password is incorrect ";
		header("location:login.php");
	}
}
else{
	$_SESSION['msg']="username and password is incorrect";
	header("location:login.php");
}
?>