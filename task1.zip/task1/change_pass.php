<?php 
include 'header.php';
include 'db.php';
if (! isset ( $_SESSION ['is_user_logged_in'] ))
{
    header('location:login.php');
}
include("user_header.php");
?>

<div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
          <?php include 'sidebar.php'; ?>
         </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
           <h2 class="sub-header">Change Password</h2>
          <div class="table-responsive">
          
      <form class="form-horizontal" role="form" action="save_pass.php" method="post">
       <br/>
       <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Old Password</label>
                    <div class="col-sm-9">
                        <input type="password" id="" name="c_pass" placeholder="password" class="form-control" autofocus value="">
                    </div>
                </div>
                <br/>
       <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">New Password</label>
                    <div class="col-sm-9">
                        <input type="password" id="" name="n_pass" placeholder="password" class="form-control" autofocus value="">
                    </div>
                </div>
                <br/>
       <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Confirm New Password</label>
                    <div class="col-sm-9">
                        <input type="password" id="" name="cn_pass" placeholder="password" class="form-control" autofocus value="">
                    </div>
                </div>
               <br/>
                <div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                        <button type="submit" name="submit" class="btn btn-primary btn-block">Change Password</button>
                    </div>
                </div>
            </form> <!-- /form -->
         
            
          </div>

        </div>
      </div>
    </div>
     <?php include 'footer.php';?>
    
  
   

    
  </body>
</html>