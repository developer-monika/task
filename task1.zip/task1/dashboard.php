<?php 
include 'user_header.php';
include 'db.php';
if (! isset ( $_SESSION ['is_user_logged_in'] ))
{
    header('location:login.php');
}
?>
<div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
          <?php include 'sidebar.php'; ?>
         </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
         <h2>Welcome to Our Website...</h2>
         <h2 class="sub-header">Hello !!!
          <?php echo $_SESSION['name'];?>
         </h2>
         <?php
      if(isset($_SESSION['msg']))
      {
        echo $_SESSION['msg'];
        unset($_SESSION['msg']);
      }
      ?>
        </div>
      </div>
    </div>
     <?php include 'footer.php';?>
    
  
   

    
  </body>
</html>