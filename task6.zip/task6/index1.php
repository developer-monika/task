<?php
for ($i=0; $i<=5 ; $i++) 
{ 
  for ($j=1; $j<=$i; $j++) 
  { 
  		echo "*";
  }	
  echo "<br/>";
}
?>
<br/>
<?php
for ($i=0; $i<=5 ; $i++) 
{ 
	for ($j=1; $j<=$i; $j++) 
	{ 
		echo "*";
	}
	   echo "</br>";
}
?>