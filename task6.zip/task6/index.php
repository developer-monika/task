<?php
for ($i=0; $i<=5 ; $i++) 
{ 
  for ($j=1; $j<=$i; $j++) 
  { 
      echo "*";
  } 
  echo "<br/>";
}
?>
<br/>
<?php
for ($i=0; $i<=5 ; $i++) 
{ 
  for ($j=1; $j<=$i; $j++) 
  { 
    echo "*";
  }
     echo "</br>";
}
?>
<br/>

<?php


for($a=5; $a>=1; $a--)
{
if($a%2 != 0)
{
for($b=5; $b>=$a; $b--)
{
     echo " ";
     echo "*";
}
     echo "<br>";
}
}
for($a=2; $a<=5; $a++)
{
 if($a%2 != 0)
{
 for($b=5; $b>=$a; $b--)
{
  echo "  ";
  echo "*";
}
echo "<br>";
}
}

?>
