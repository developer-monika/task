<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		p{
			color: red;
		}
	</style>
</head>
<body>
<?php
	//$data is a array variable which contain some keys and values
	$data=array("11"=>"a","12"=>"b","13"=>"c","14"=>"d");
	    echo "<p>Array which contain Keys and Values</p>";
	    //This var_dump() return its type and value
	    var_dump($data);
	    echo "<br /><p>Array with key</p>";
		//print index with key
		print_r(array_keys($data));


	$data=array("11"=>"a","12"=>"b","13"=>"c","14"=>"d");
	    echo "<br \><p>Array with values </p>";
	    //print index with value
	    print_r(array_values($data));


?>
</body>
</html>



</br></br></br>
<!-- <?php
//$a=array {“11””a”, “12””b”, “13””c”, “14””d”}
$arr = array(
   11 => "a",
   12 => "b",
   13 => "c",
   14 => "d"
);
foreach($arr as $v){
	echo "Value is:";
    echo($v)."</br>";  

}
foreach ($arr as $key => $value) {
 echo "<br/>";
 echo "Key is:";
 echo $key;
 echo "Valuse is:";
 echo $value;
 echo "</br>";
}
?> -->