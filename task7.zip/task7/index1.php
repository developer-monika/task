<?php
	//$data is a array variable which contain some keys and values
	$data=array("11"=>"a","12"=>"b","13"=>"c","14"=>"d");
	    echo "Array which contain Keys and Values<br />";
	    //This var_dump() return its type and value
	    var_dump($data);
	    echo "<br />Array with key <br />";
		//print index with key
		print_r(array_keys($data));


	$data=array("11"=>"a","12"=>"b","13"=>"c","14"=>"d");
	    echo "<br \>Array with values <br \>";
	    //print index with value
	    print_r(array_values($data));


?>