<?php include 'header.php';?>
    <div class="container">
	<br/><br/><br/><br/><br/>
    <!-- Main form -->
   <div class="container">
            <form class="form-horizontal" role="form" action="" method="post" id="formID" class="formular">
                <h2>Registration Form</h2>
                <div class="form-group">
                    <label for="Username" class="col-sm-3 control-label">Username</label>
                    <div class="col-sm-9">
                        <input type="email" id="" name="username" placeholder="Username" class="form-control validate[required]">
                    </div>
                </div>
                <div class="form-group">
                    <label for="password" class="col-sm-3 control-label">Password</label>
                    <div class="col-sm-9">
                        <input type="password" id="" name="password" placeholder="Password" class="form-control validate[required]">
                    </div>
                </div>
				 <div class="form-group">
                    <label for="password" class="col-sm-3 control-label">Confirm  password </label>
                    <div class="col-sm-9">
                        <input type="password" id="" name="repass" placeholder="Confirm  password" class="form-control validate[required]">
                   </div>
                </div>
                <div class="form-group">
                    <label for="Address" class="col-sm-3 control-label">Address</label>
                    <div class="col-sm-9">
                        <textarea cols="45" rows="5" name="address" placeholder="Entar Your Address Here "></textarea>
                    </div>
                </div>

                <div class="form-group">
                    <label for="City" class="col-sm-3 control-label">City</label>
                    <div class="col-sm-9">
                        <select id="" name="city" class="form-control validate[required]">
                             <option>Mumbai</option>
                            <option>Indore</option>
                            <option>Delhi</option>
                            <option>Chennai</option>
                            <option>Bhopal</option>
                        </select>
                    </div>
                </div> <!-- /.form-group -->
                <div class="form-group">
                    <label class="control-label col-sm-3">Gender</label>
                    <div class="col-sm-6">
                        <div class="row">
                            <div class="col-sm-4">
                                <label class="radio-inline">
                                    <input type="radio" id="" name="gender" value="Female">Female
                                </label>
                            </div>
                            <div class="col-sm-4">
                                <label class="radio-inline">
                                    <input type="radio" id="" name="gender" value="Male">Male
                                </label>
                            </div>
                        </div>
                    </div>

                </div> <!-- /.form-group -->
                <div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                        <button type="submit" name="submit" class="btn btn-primary btn-block">Sign Up</button>
                    </div>
                </div>
            </form> <!-- /form -->
        </div> <!-- ./container -->
 </div> <!-- /container -->
    
      <hr>
    <?php include 'footer.php';?>
    </body>
</html>