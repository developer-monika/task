<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Task1</title>
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/dashboard.css" rel="stylesheet">
    <script type="text/javascript" src="js/jquery-1.9.1.js"></script>
    <!--code-->
    <script>
    jQuery(document).ready(function(){
      // binds form submission and fields to the validation engine
      jQuery("#formID").validationEngine();
    });
    /**
    *
    * @param {jqObject} the field where the validation applies
    * @param {Array[String]} validation rules for this field
    * @param {int} rule index
    * @param {Map} form options
    * @return an error string if validation failed
    */
    function checkHELLO(field, rules, i, options){
      if (field.val() != "HELLO") {
        // this allows to use i18 for the error msgs
        return options.allrules.validate2fields.alertText;
      }
    }
  </script>
  </head>
  </script>
  <body>
    <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php">Task1</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
        <ul class="nav navbar-nav pull-right">
           <li class="active"><a href="index.php">Home</a></li>
           <li><a href="login.php">Login</a></li>
           <li><a href="signup.php">Sign Up</a></li>
        </ul>
        </div><!--/.navbar-collapse -->
      </div>
    </nav>