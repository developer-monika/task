<!DOCTYPE html>
<html>
<head>
	<title></title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
	<!-- <script type="text/javascript" src="js/jquery.js"></script> -->
<script type="text/javascript">
	$(document).ready(function(){
		$("[type='submit']").click(function(){
			var a=$("#full_name").val();
			var b=$("#email").val();
			var c=$("#pass").val();
			var d=$("#re_pass").val();
			var e=$("#contact").val();
			var f=$("#city").val();
			var g=$("#ope_balance").val();

			var h=$("#male").is(":checked");
			var i=$("#female").is(":checked");
			var check=true;
			// var focus="";
			if(h==false && i==false)
			{
				$("#gender_msg").html("Select Gender");
				// focus="#full_name_msg";
				check=false;
			}
			else
			{
				$("#gender_msg").html("");

			}

			if(a=="")
			{
				$("#full_name_msg").html("Insert Your Full Name");
				// focus="#full_name_msg";
				check=false;
			}
			else
			{
				$("#full_name_msg").html("");
			}
			if(b=="")
			{
				$("#email_msg").html("Insert Your Email");
				// focus="#email_msg";
				check=false;
			}
			else
			{
				$("#email_msg").html("");
				var reg=/^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/; 
				if(reg.test(b)==false)
				{
					$("#email_msg").html("Insert Correct Email");
					check=false;
				}
				else
				{
					$("#email_msg").html("");

				}
			}
			if(c=="")
			{
				$("#pass_msg").html("Insert Your Password");
				// $("#pass").focus();
				check=false;
			}
			else
			{
				$("#pass_msg").html("");
				if(c != d)
				{
					$("#re_pass_msg").html("Correct Your Re-Password");
					check=false;
				}
				else
				{
					
					$("#re_pass_msg").html("");
				}
			}
			if(e=="")
			{
				$("#contact_msg").html("Insert Your Contact Number");
				check=false;
			}
			else
			{
				if(isNaN(e)==true)
				{
					$("#contact_msg").html("Insert Number Only");
					check=false;
				}
				else
				{
					
					$("#contact_msg").html("");
					if(e.length != 10)
					{
						$("#contact_msg").html("Insert 10 Digit Only");
						check=false;
					}
					else
					{
						$("#contact_msg").html("");
					}
				}
			}
			if(f=="Select")
			{
				$("#city_msg").html("Select Your City");
				check=false;
			}
			else
			{
				$("#city_msg").html("");

			}

			if(check==false)
			{
				$("#pass").val("");
				$("#re_pass").val("");
			}

			return check;

		});
	});
</script>
<style type="text/css">
	.error{
		font-size: 12px;
		color: red;
	}
	span{
		color: red;
		font-size: 14px;
	}
	.container{
		margin: 0 auto;
		width: 700px;
	}
</style>
</head>
<body>
<div class="content">
<div class="container">
		<h2 class="welcome text-center">User Registration/ jquery validation</h2>
		<div class="box-shadow" style="width:400px;"">
			<form action="save.php" method="post">
				<table align="center">
					<tr>
					
					</tr>
					<tr>
						<td>Full Name<span>*</span></td>
						<td><input type="Text" placeholder="Full Name" id="full_name" name="full_name"/></td>
					</tr>
					<tr class="error">
						<td></td>
						<td id="full_name_msg"></td>
					</tr>
					<tr>
						<td>Email</td>
						<td><input type="Text" placeholder="Email" id="email" name="email"/></td>
					</tr><tr class="error">
						<td></td>
						<td id="email_msg"></td>
					</tr>
					<tr>
						<td>Password</td>
						<td><input type="password" placeholder="Password" id="pass" name="password"/></td>
					</tr><tr class="error">
						<td></td>
						<td id="pass_msg"></td>
					</tr>
					<tr>
						<td>Re-Password</td>
						<td><input type="password" placeholder="Re-Password" id="re_pass" name="re_pass"/></td>
					</tr><tr class="error">
						<td></td>
						<td id="re_pass_msg"></td>
					</tr>
					
					<tr>
						<td>Contact</td>
						<td><input type="Text" placeholder="Contact" id="contact" name="contact"/></td>
					</tr><tr class="error">
						<td></td>
						<td id="contact_msg"></td>
					</tr>
					<tr>
						<td>City</td>
						<td><select name="city" id="city">
							<option>Select</option>
							<option>Indore</option>
							<option>Mumbai</option>
							<option>Bhopal</option>
							<option>Ujjain</option>
							
						</select></td>
					</tr><tr class="error">
						<td></td>
						<td id="city_msg"></td>
					</tr>
					<tr>
						<td>Gender</td>
						<td>Male<input type="radio" name="gender" id="male" value="male"/>Female<input type="radio" name="gender" id="female" value="female"/></td>
					</tr><tr class="error">
						<td></td>
						<td id="gender_msg"></td>
					</tr>
					<tr>
						
						<td colspan="2" align="center"><input type="submit" class="button" value="Signup" name="submit"/></td>
					</tr>
					<tr>
						<td colspan="2">Alredy Have An Account Click <a href="login.php">Login <i class="fa fa-sign-in"></i> </a></td>
					</tr>
				</table>
			</form>
		</div>
</div>
</div>

</body>
</html>


