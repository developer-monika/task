<?php //if they DID upload a file...
if($_FILES['photo']['name'])
{
	//if no errors...
	if(!$_FILES['photo']['error'])
	{
		//now is the time to modify the future file name and validate the file
		$new_file_name = strtolower($_FILES['photo']['tmp_name']); //rename file
		if($_FILES['photo']['size'] > (102400000)) //can't be larger than 1 MB
		{
			$valid_file = false;
			$message = 'Oops!  Your file\'s size is to large.';die;
		}
		$valid_file=true;
		//if the file has passed the test
		if($valid_file)
		{
			//move it to where we want it to be
			include("db.php");
			$picture = $_FILES['photo']['name'];
			$que="INSERT INTO fileupload (picture) VALUES ('$picture')";
			mysql_query($que);
			//mysqli_query($con, $que);
			
			  $folder="uploads/";
		

			move_uploaded_file($_FILES['photo']['tmp_name'], $folder.$picture);
			$message = 'Congratulations!  Your file was accepted.';
			header('location:index.php');
		}

	}
	//if there is an error...
	else
	{
		//set that to be the returned message
		$message = 'Ooops!  Your upload triggered the following error:  '.$_FILES['photo']['error'];
	}
}

//you get the following information for each file:
?>
