<!DOCTYPE html>
<html>
<head>
	<title>swap words</title>
</head>
<body>
<?php

//echo str_replace("Future", "sapna", "Future");
//echo "&nbsp;";
//echo str_replace("Technologies", "sangeeta", "Technologies");

$arr=("sapna sangeeta");
echo str_replace("sapna sangeeta", "Future Technologies", $arr);
?>
</body>
</html>