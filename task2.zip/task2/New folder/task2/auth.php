<?php
$conn = mysqli_connect("localhost", "root", "", "monica");
// mysql_select_db("monica", $conn);
	$sql = "Select * from members where member_email = '" . $_POST["member_name"] . "' and member_password = '" . $_POST["member_password"] . "'";

	$result = mysqli_query($conn,$sql);
	if (mysqli_num_rows($result)==1){
		$user = mysqli_fetch_array($result);
		//print_r($user);
		$_SESSION["member_id"]= $user["member_id"];

		if(!empty($_POST["remember"])) {
				// echo 1;die;
			setcookie ("member_login",$_POST["member_name"],time()+ (10 * 365 * 24 * 60 * 60));
			setcookie ("member_password",$_POST["member_password"],time()+ (10 * 365 * 24 * 60 * 60));
				
		}
		header("Location:dashboard.php");
	}
	
	

?>