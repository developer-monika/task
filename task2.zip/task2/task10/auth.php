<?php
$con = mysql_connect("localhost","root","");
mysql_select_db("task2_db", $con);
//$conn = mysqli_connect("localhost", "root", "", "task2_db");
$sql = "Select * from members where member_name = '" . $_POST["member_name"] . "' and member_password = '" . $_POST["member_password"] . "'";

	$result = mysql_query($sql);
	if (mysql_num_rows($result)==1){
		$user = mysql_fetch_array($result);
		//print_r($user);
		$_SESSION["member_id"]= $user["member_id"];

		if(!empty($_POST["remember"])) {
				//echo 1;die;

			setcookie ("member_name",$_POST["member_name"],time()+ (10 * 365 * 24 * 60 * 60));
			setcookie ("member_password",$_POST["member_password"],time()+ (10 * 365 * 24 * 60 * 60));
				
		}
		header("location:dashboard.php");
	}
?>