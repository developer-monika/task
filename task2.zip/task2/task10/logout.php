<?php
session_start();
$_SESSION["member_id"] = "";
session_destroy();
setcookie("member_name", "", time() - 3600);
setcookie("member_password", "", time() - 3600);
header("location: index.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h5>Succcessfully logout</h5>
</body>
</html>