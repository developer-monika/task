<?php
session_start();
$_SESSION["member_id"] = "";
session_destroy();
setcookie("member_login", "", time() - 3600);
header("Location: ./");
?>