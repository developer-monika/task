<?php
$con=mysql_connect("localhost", "root","");
mysql_select_db("task1", $con);
session_start();
?>
