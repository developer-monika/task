<?php
$a="admin";
echo "admin";
echo "<br/>";
echo md5("$a");
echo "<br/>";
echo md5("admin");
?>