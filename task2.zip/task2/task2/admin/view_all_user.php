<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Task1</title>
     <!-- Bootstrap -->
    <!--<link href="css/bootstrap.min.css" rel="stylesheet">-->
  <link href="../css/bootstrap.css" rel="stylesheet">
  <link href="../css/style.css" rel="stylesheet">
   <link
    href="../css/dashboard.css" rel="stylesheet">
 
  </head>
  
   <body>
<?php include '../user_header.php';?>
<?php
include("../db.php");
if(! isset($_SESSION['is_admin_logged_in']))
{
  header("location:../index.php");
}
$que="SELECT * FROM info_tbl";
$obj=mysql_query($que);
?>
<div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
          <ul class="nav nav-sidebar">
            <li class="active"><a href="overview.php">Overview <span class="sr-only">(current)</span></a></li>
             <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="view_all_user.php">View all User </a></li>
           <li><a href="logout.php">Logout</a></li>
          </ul>
         </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
         <h2 class="sub-header">All user list!!!</h2>
       <div class="table-responsive">
          
            <table class="table table-striped">
             <tbody>
             <tr>
          <th>S.No.</th>
          <th>User Name</th>
          <th>Address</th>
          <th>City</th>
          <th>Gender</th>
          <th>Delete User</th>
        </tr>
             <?php
             $n=1;
             while($data=mysql_fetch_assoc($obj))
             {
              echo "<tr>";
              echo "<td>".$n."</td>";
              echo "<td>".$data['username']."</td>";
              echo "<td>".$data['address']."</td>";
              echo "<td>".$data['city']."</td>";
              echo "<td>".$data['gender']."</td>";
              echo "<td><a href='delete_user.php?id=".$data['id']."'>Delete</a></td>";
              echo "</tr>";
              $n++;
            }
              ?>
               
              
                
               
               
              </tbody>
            </table>
            
          </div>
        </div>
      </div>
    </div>
     <?php include '../footer.php';?>
    
  
   

    
  </body>
</html>