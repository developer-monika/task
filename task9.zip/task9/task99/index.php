<!DOCTYPE html>
<html>
<head>
	<title>Buid logic using  JavaScript....</title>
	<style type="text/css">
		.container{
			margin: 0 auto;
			width: 500px;
		}
	</style>
	<script type="text/javascript">
		 function checkdropdown() {
      if(document.getElementById('select').value != "") {
        return true;
      }
      else {
        return false;
      }
    }
	</script>
</head>
<body>
<div class="container">
<div class="center">
	<form action='save.php' action='post'>
      <select name='select' id='select'>
        <option value=''>Select an option</option>
        <option value='Indore'>Indore</option>
        <option value='Bhopal'>Bhopal</option>
        <option value='Pune'>Pune</option>
        <option value='Mumbai'>Mumbai</option>
        <option value='Delhi'>Delhi</option>
      </select>
    <input type='submit' onClick='if(!checkdropdown()) {alert("You need to select a city!"); return false;}' value='Submit' />
    </form>
</div>
</div>
</body>
</html>