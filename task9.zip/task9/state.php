<?php

include('connect.php');

?>

<!DOCTYPE html>
<html>
<head>
	<title>State</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>


	<script type="text/javascript">
		$(document).ready(function(){
			$('#state2').attr('disabled', true);
			$('#state3').attr('disabled', true);
			$('#state1').change(function(){
				var val = document.getElementById('state1').value;
				if (val != '0') {
							$('#state2').attr('disabled', false);
						}
				// alert(val);
				
				$.ajax({
					type: 'POST',
					url: 'select.php',
					data: {state:val},
					success: function(response){
						var json = $.parseJSON(response);
						var length = json.length;
						var	html = '<option value="0">Select State Please</state>';
						for (var i = 0; i < length; i++) {
							html += '<option value="'+json[i]+'">'+json[i]+'</option>';	
						}
						
						
						$('#state2').html(html);
					}
				
				});
			});

			$('#state2').change(function(){
				var val = document.getElementById('state1').value;
				var val2 = document.getElementById('state2').value;
				// alert(val);
				// alert(val2);
				if(val == val2){
					// alert();
					$('.state2error').text("please select different state");
				}else{
					$('.state2error').text("");
				}
			 	// alert(val2);
				var val1 = [val,val2];
				// $('#state3').attr('disabled', false);
				$.ajax({
					type: 'POST',
					url: 'select.php',
					data: {state1:val1},
					success: function(response){
						var json = $.parseJSON(response);
						var length = json.length;
						var	html = '<option value="0">Select State Please</state>';
						for (var i = 0; i < length; i++) {
							html += '<option value="'+json[i]+'">'+json[i]+'</option>';	
						}
						if (val2 != 0) {
							// alert('if');
							$('#state3').attr('disabled', false);
						}
						else{
							// alert('else');
							$('#state3').attr('disabled', true);
						}
						$('#state3').html(html);
					}
				
				});
			});

			$('#state3').change(function(){
				var val = document.getElementById('state1').value;
				var val2 = document.getElementById('state2').value;
				var val3 = document.getElementById('state3').value;
				if(val == val3){
					// alert();
					$('.state3error').text("please select different state");
				}else if(val2 == val3){
						$('.state3error').text("please select different state");
					}else{
							$('.state3error').text("");
					}
			
		});
		});
		
	</script>
</head>
<body>
<div>
	<select name="state1" id="state1">
		<option value="0">Select State Please </option>
		<?php
			$query = "SELECT `state` FROM `state`";
			$result = mysqli_query($conn,$query);
			while ($row = mysqli_fetch_array($result)) {
		?>
			<option value="<?php echo $row['state']; ?>"><?php echo $row['state']; ?></option>
		<?php
			}
		?>

	</select>
</div>

<div>
	<select name="state2" id="state2">
		<option value="0">Select State Please </option>
		
	</select>

		<span class="state2error"></span>
</div>

<div>
	<select name="state3" id="state3">
		<option value="">Select State Please </option>
			

	</select>
	<span class="state3error"></span>
</div>
</body>
</html>
