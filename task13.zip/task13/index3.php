<?php
$con=mysql_connect("localhost","root","");
mysql_select_db("stgwordpress", $con);
//$que="SELECT * FROM cities";
$que="SELECT * FROM cities ORDER BY city_state ASC";
$obj=mysql_query($que);
$n=1;
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h2  style="color:red; text-align:center;">Returns a list of states with the number of cities in that state</h2>
<table align="center" border="1" width="500">
	<tr>
		<th>#</th>
		<th>State Name</th>
		<th>City Name</th>
	</tr>
	<?php
	
	while($data=mysql_fetch_assoc($obj))
	{
		echo "<tr>";
		echo "<td>".$n."</td>";
		echo "<td>".$data['city_state']."</td>";
		echo "<td>".$data['city_name']."</td>";
		echo "</tr>";
		$n++;
	}
	?>
</table>

?>
</body>
</html>