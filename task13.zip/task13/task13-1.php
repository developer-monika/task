
<?php
$con=mysql_connect("localhost","root","");
mysql_select_db("task13_db", $con);
//$que="SELECT * FROM cities";
//$que="SELECT city_state FROM cities ORDER BY city_state DESC";
//$que2="SELECT first_name, last_name, order_date, order_amount
 //FROM customer_tbl INNER JOIN order_tbl ON customer_tbl.customer_id = order_tbl.customer_id
//$que ="SELECT * FROM state_tbl ORDER BY state_name DESC";
$que="SELECT * FROM state_tbl INNER JOIN city_tbl ON state_tbl.state_id = city_tbl.state_id ORDER BY state_name";
$obj=mysql_query($que);
$n=1;
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h2 style="color:red; text-align:center;">Returns a list of cities &amp; there states in alphabetical order of name of state</h2>
<br/><br/>
<table align="center" border="1" width="500">
	<tr>
		<th>#</th>
		<!-- <th>City Name</th> -->
		
		<th>City name</th>
		<th>State Name</th>
	</tr>
	<?php
	
	while($data=mysql_fetch_assoc($obj))
	{
		echo "<tr>";
		echo "<td>".$n."</td>";
		//echo "<td>".$data['city_name']."</td>";
		
		echo "<td>".$data['city_name']."</td>";
		echo "<td>".$data['state_name']."</td>";
		echo "</tr>";
		$n++;
	}
	?>
</table>

?>
</body>
</html>