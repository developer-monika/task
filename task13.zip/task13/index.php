<!DOCTYPE html>
<html>
<head>
	<title>SQL</title>
	<style type="text/css">
		li a{
        color: grey;
        font-size: 18px;
        font-weight: bold;
        text-decoration: none;
		}
	</style>
</head>
<body>
<ul>
	<li><a href="task13.php" target="/blank">Return a list of states in descending order of number of cities in the state</a></li>
	<li><a href="task13-1.php" target="/blank">Returns a list of cities &amp; there states in alphabetical order of name of state</a></li>
	<li><a href="task13-2.php" target="/blank">Returns a list of states with the number of cities in that state</a></li>
	<!-- <li><a href="index4.php" target="blank">All state from india in Ascedding order</a></li>
	<li><a href="index5.php" target="/blank">All Data india city/state</a></li> -->
</ul>
</body>
</html>