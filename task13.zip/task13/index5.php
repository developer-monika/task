<?php
$con=mysql_connect("localhost","root","");
mysql_select_db("stgwordpress", $con);
$que="SELECT * FROM cities";
$obj=mysql_query($que);
$n=1;
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h2  style="color:red; text-align:center;">All city/state from india</h2>
<table align="center" border="1" width="500">
	<tr>
		<th>#</th>
		<th>City Name</th>
		<th>State Name</th>
	</tr>
	<?php
	
	while($data=mysql_fetch_assoc($obj))
	{
		echo "<tr>";
		echo "<td>".$n."</td>";
		echo "<td>".$data['city_name']."</td>";
		echo "<td>".$data['city_state']."</td>";
		echo "</tr>";
		$n++;
	}
	?>
</table>

?>
</body>
</html>