<?php
$con=mysql_connect("localhost","root","");
mysql_select_db("task13_db", $con);
$que ="SELECT COUNT(city_tbl.city_name),state_tbl.state_name FROM state_tbl, city_tbl WHERE state_tbl.state_id=city_tbl.state_id Group By city_tbl.state_id; ";
$obj=mysql_query($que);
$n=1;
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h2 style="color:red; text-align:center;">Returns a list of states with the number of cities in that state</h2>
<br/><br/>
<table align="center" border="1" width="500">
	<tr>
		<th>#</th>
		<!-- <th>City Name</th> -->
		<th>State Name</th>
		<th>No</th>
	</tr>
	<?php
	
	while($data=mysql_fetch_assoc($obj))
	{
		echo "<tr>";
		echo "<td>".$n."</td>";
		//echo "<td>".$data['city_name']."</td>";
		echo "<td>".$data['state_name']."</td>";
		echo "<td>".$data['COUNT(city_tbl.city_name)']."</td>";
		echo "</tr>";
		$n++;
	}
	?>
</table>

</body>
</html>