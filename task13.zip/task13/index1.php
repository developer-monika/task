<?php
$con=mysql_connect("localhost","root","");
mysql_select_db("stgwordpress", $con);
$que ="SELECT DISTINCT city_state FROM cities ORDER BY city_state DESC";
$obj=mysql_query($que);
$n=1;
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h2 style="color:red; text-align:center;">Return a list of states in descending order of number of cities in the state</h2>
<br/><br/>
<table align="center" border="1" width="500">
	<tr>
		<th>#</th>
		<!-- <th>City Name</th> -->
		<th>State Name</th>
	</tr>
	<?php
	
	while($data=mysql_fetch_assoc($obj))
	{
		echo "<tr>";
		echo "<td>".$n."</td>";
		//echo "<td>".$data['city_name']."</td>";
		echo "<td>".$data['city_state']."</td>";
		echo "</tr>";
		$n++;
	}
	?>
</table>

?>
</body>
</html>