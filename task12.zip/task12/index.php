<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php
include('db.php');

$sqlimage  = "SELECT picture FROM fileupload";

$imageresult1 = mysql_query($sqlimage);

while($rows=mysql_fetch_assoc($imageresult1))
{
    $image = $rows['picture'];
    //echo "<img src='$image' >";
   
    echo '<img src="uploads/'.$image.'" />';
    
   // echo "<br>";
} 
?>
</body>
</html>